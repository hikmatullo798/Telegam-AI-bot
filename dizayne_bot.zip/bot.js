require('dotenv').config();
const { Telegraf } = require('telegraf');
const { Configuration, OpenAIApi } = require('openai');

const bot = new Telegraf(process.env.BOT_TOKEN);

const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

const topics = [
    "2025 yilda UI dizayn trendlar",
    "UX va psixologiya o‘zaro bog‘liqligi",
    "Minimalist dizaynning afzalliklari",
    "Dark mode dizayn qoidalari",
    "Figma prototiplash usullari",
    "Mobil ilovalar uchun responsive dizayn",
    "AI dizaynerlarga qanday yordam beradi"
];

const GROUP_CHAT_ID = process.env.GROUP_CHAT_ID;

async function sendArticle() {
    const topic = topics[Math.floor(Math.random() * topics.length)];
    try {
        const response = await openai.createChatCompletion({
            model: 'gpt-4o',
            messages: [{
                role: 'user',
                content: `Dizayn sohasida "${topic}" mavzusida 200-300 so'zli maqola yozing.`
            }],
            temperature: 0.7,
        });

        const article = response.data.choices[0].message.content;

        await bot.telegram.sendMessage(GROUP_CHAT_ID, `📚 *${topic}*

${article}`, { parse_mode: 'Markdown' });
        console.log(`Maqola yuborildi: ${topic}`);

    } catch (error) {
        console.error('Maqola yaratishda xatolik:', error.message);
    }
}

setInterval(sendArticle, 86400000);

bot.launch();
console.log('Bot ishga tushdi va avtomatik maqolalarni yuborishni boshladi!');